# DSH port provenance — academic-paper

- upstream: https://github.com/Imbad0202/academic-research-skills
- commit: `d103b1005bb8c9f7a597e6a7ed473b75dcf8830e`
- license: CC-BY-NC-4.0
- copyright: Copyright (c) 2026 Cheng-I Wu
- imported: 2026-11-23
- packaged files: 224
- uninstall: remove this directory (`~/.dsh/skills/academic-paper`)

## Modifications

- DSH port note prepended to SKILL.md (tool names, `$ARGUMENTS`, notices).
- Upstream repository-root `shared/` merged into this skill directory so relative references resolve.
- Added `NOTICE.md` and `LICENSE.txt` (and, for venue-templates, LPPL notices).
