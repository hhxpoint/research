# sr-screener — NOTICE / 第三方声明

- Upstream project: https://github.com/Imbad0202/academic-research-skills
- Pinned commit: `d103b1005bb8c9f7a597e6a7ed473b75dcf8830e`
- License: CC-BY-NC-4.0 (https://creativecommons.org/licenses/by-nc/4.0/)
- Copyright: Copyright (c) 2026 Cheng-I Wu
- DSH adaptation date: 2026-11-23; see `DSH-PORT.md` for every modification.

This directory is redistributed as part of <https://github.com/hhxpoint/research>.
The full licence text of the upstream project is in `LICENSE.txt` in this directory.

## Non-commercial only / 仅限非商业使用

ARS is licensed under **CC BY-NC 4.0**: personal academic use and non-commercial
research are allowed; **commercial use is prohibited** without a separate licence
from the upstream author (Cheng-I Wu).
Sharing/adaptation requires attribution and an indication of changes (both provided
here and in `DSH-PORT.md`).
