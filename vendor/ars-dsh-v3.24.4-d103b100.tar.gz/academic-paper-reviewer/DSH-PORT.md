# DSH port provenance — academic-paper-reviewer

- upstream: https://github.com/Imbad0202/academic-research-skills
- commit: `d103b1005bb8c9f7a597e6a7ed473b75dcf8830e`
- license: CC BY-NC 4.0 仅限非商业学术用途，商用需另行授权
- imported: 2026-11-23
- upstream SKILL.md: unchanged body, DSH port note prepended
- merged dirs: ['shared']
- files installed: 184
- extra notes: —
- uninstall: remove this directory (`~/.dsh/skills/academic-paper-reviewer`)
